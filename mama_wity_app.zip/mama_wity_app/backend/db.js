import mysql from "mysql2";

export const db = mysql.createConnection({
  host: process.env.DB_HOST || "YOUR_DB_HOST",
  user: process.env.DB_USER || "YOUR_DB_USER",
  password: process.env.DB_PASS || "YOUR_DB_PASS",
  database: process.env.DB_NAME || "mama_wity_db"
});

db.connect(err => {
  if (err) console.log("Database connection failed:", err);
  else console.log("Connected to MySQL ✅");
});