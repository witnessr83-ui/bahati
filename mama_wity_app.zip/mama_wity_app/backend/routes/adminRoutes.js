import express from "express";
import { db } from "../db.js";

const router = express.Router();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "ndescoadmin2025";

// Simple password auth (no sessions) - frontend must remember success state
router.post("/login", (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) return res.json({ success: true });
  res.status(401).json({ success: false, message: "Invalid password" });
});

// CRUD: services
router.get("/services", (req, res) => {
  db.query("SELECT * FROM services ORDER BY id DESC", (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

router.post("/services", (req, res) => {
  const { name, price, description } = req.body;
  db.query("INSERT INTO services (name, price, description) VALUES (?, ?, ?)", 
    [name, price, description], (err, result) => {
      if (err) return res.status(500).send(err);
      res.json({ success: true, id: result.insertId });
    });
});

router.put("/services/:id", (req, res) => {
  const { id } = req.params;
  const { name, price, description } = req.body;
  db.query("UPDATE services SET name=?, price=?, description=? WHERE id=?", 
    [name, price, description, id], err => {
      if (err) return res.status(500).send(err);
      res.json({ success: true });
    });
});

router.delete("/services/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM services WHERE id=?", [id], err => {
    if (err) return res.status(500).send(err);
    res.json({ success: true });
  });
});

// Settings: working hours + social links (single-row table 'settings' id=1)
router.get("/settings", (req, res) => {
  db.query("SELECT * FROM settings WHERE id=1", (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results[0] || {});
  });
});

router.post("/settings", (req, res) => {
  const { opening_hours, instagram, facebook, twitter } = req.body;
  // Upsert pattern
  db.query("INSERT INTO settings (id, opening_hours, instagram, facebook, twitter) VALUES (1, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE opening_hours=VALUES(opening_hours), instagram=VALUES(instagram), facebook=VALUES(facebook), twitter=VALUES(twitter)",
    [opening_hours || '', instagram || '', facebook || '', twitter || ''], err => {
      if (err) return res.status(500).send(err);
      res.json({ success: true });
    });
});

export default router;