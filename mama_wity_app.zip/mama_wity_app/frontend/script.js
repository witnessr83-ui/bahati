const API_BASE = "/api/admin"; // When deploying to Vercel, this should work as is for server root
let clickCount = 0;
const logo = document.getElementById('logo');
const adminPanel = document.getElementById('admin-panel');
const loginBtn = document.getElementById('login-btn');
const adminPass = document.getElementById('admin-pass');
const adminDashboard = document.getElementById('admin-dashboard');
const manageServices = document.getElementById('manage-services');
const servicesList = document.getElementById('services-list');
const addServiceBtn = document.getElementById('add-service-btn');
const saveSettingsBtn = document.getElementById('save-settings');

// Click 5 times to toggle admin panel visibility
logo.addEventListener('click', ()=>{
  clickCount++;
  if(clickCount >= 5){
    adminPanel.classList.toggle('hidden');
    clickCount = 0;
  }
  setTimeout(()=>{ clickCount = 0; }, 1500);
});

function showPage(name){
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  const el = document.getElementById(name);
  if(el) el.classList.remove('hidden');
}

// Load services for public view
async function loadPublicServices(){
  try{
    const res = await fetch(API_BASE + '/services');
    const data = await res.json();
    const container = document.getElementById('services-list');
    container.innerHTML = data.map(s => `
      <div class="service-card">
        <h3>${s.name}</h3>
        <p>${s.description}</p>
        <strong>TSh ${s.price}</strong>
        <div style="margin-top:8px">
          <a href="https://wa.me/255745101534" target="_blank" class="cta" style="padding:8px 12px;font-size:14px">Order WhatsApp</a>
        </div>
      </div>
    `).join('');
  }catch(e){
    console.error('Could not load services (public)', e);
  }
}

// Admin login
loginBtn.addEventListener('click', async ()=>{
  try{
    const res = await fetch(API_BASE + '/login', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ password: adminPass.value })
    });
    if(res.ok){
      adminDashboard.classList.remove('hidden');
      document.getElementById('admin-login').classList.add('hidden');
      loadAdminContent();
    }else{
      alert('Password si sahihi!');
    }
  }catch(e){
    console.error(e); alert('Server error');
  }
});

async function loadAdminContent(){
  // load settings
  try{
    const res = await fetch(API_BASE + '/settings');
    const settings = await res.json();
    document.getElementById('opening-hours').value = settings.opening_hours || '';
    document.getElementById('instagram').value = settings.instagram || '';
    document.getElementById('facebook').value = settings.facebook || '';
    document.getElementById('twitter').value = settings.twitter || '';
  }catch(e){ console.warn('Could not load settings', e); }

  // load services in manage area
  try{
    const res = await fetch(API_BASE + '/services');
    const data = await res.json();
    renderManageServices(data);
  }catch(e){ console.error(e); }
}

function renderManageServices(data){
  manageServices.innerHTML = data.map(s => `
    <div class="service-row" data-id="${s.id}">
      <input class="manage-input" data-field="name" value="${s.name}" />
      <input class="manage-input" data-field="price" value="${s.price}" />
      <input class="manage-input" data-field="description" data-wide value="${s.description}" />
      <button data-action="save">Save</button>
      <button data-action="delete">Delete</button>
    </div>
  `).join('');

  manageServices.querySelectorAll('[data-action="save"]').forEach(btn=>{
    btn.addEventListener('click', async (ev)=>{
      const row = ev.target.closest('.service-row');
      const id = row.dataset.id;
      const name = row.querySelector('[data-field="name"]').value;
      const price = row.querySelector('[data-field="price"]').value;
      const description = row.querySelector('[data-field="description"]').value;
      await fetch(API_BASE + '/services/' + id, {
        method: 'PUT', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ name, price, description })
      });
      alert('Updated');
      loadPublicServices();
    });
  });

  manageServices.querySelectorAll('[data-action="delete"]').forEach(btn=>{
    btn.addEventListener('click', async (ev)=>{
      if(!confirm('Una uhakika?')) return;
      const row = ev.target.closest('.service-row');
      const id = row.dataset.id;
      await fetch(API_BASE + '/services/' + id, { method:'DELETE' });
      row.remove();
      loadPublicServices();
    });
  });
}

addServiceBtn.addEventListener('click', async ()=>{
  const payload = { name: 'Huduma Mpya', price: '0', description: 'Maelezo' };
  await fetch(API_BASE + '/services', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  loadAdminContent();
  loadPublicServices();
});

saveSettingsBtn.addEventListener('click', async ()=>{
  const payload = {
    opening_hours: document.getElementById('opening-hours').value,
    instagram: document.getElementById('instagram').value,
    facebook: document.getElementById('facebook').value,
    twitter: document.getElementById('twitter').value
  };
  await fetch(API_BASE + '/settings', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  alert('Settings saved');
  loadPublicServices();
});

// initial load
showPage('home');
loadPublicServices();