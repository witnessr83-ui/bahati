Mama Wity App
==============

What you got:
- Node.js + Express backend (backend/)
- Simple frontend (index.html) with hidden admin panel (click logo 5 times to open)
- MySQL schema example
- .env.example for environment variables

Steps to run locally:
1. Install dependencies
   npm install

2. Create a .env file (copy .env.example) and fill in your MySQL credentials.

3. Create database and tables (example SQL below) and ensure DB credentials match .env.

4. Start server
   npm run dev   (if you have nodemon) or npm start

API endpoints (backend)
- POST /api/admin/login  { password }
- GET /api/admin/services
- POST /api/admin/services  { name, price, description }
- PUT /api/admin/services/:id
- DELETE /api/admin/services/:id
- GET /api/admin/settings
- POST /api/admin/settings  { opening_hours, instagram, facebook, twitter }

MySQL schema example:
CREATE DATABASE mama_wity_db;
USE mama_wity_db;
CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200),
  price VARCHAR(100),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE settings (
  id INT PRIMARY KEY,
  opening_hours VARCHAR(200),
  instagram VARCHAR(300),
  facebook VARCHAR(300),
  twitter VARCHAR(300)
);
INSERT INTO settings (id, opening_hours) VALUES (1, '8:00 AM - 9:00 PM') ON DUPLICATE KEY UPDATE opening_hours=VALUES(opening_hours);

Deploy to Vercel:
- Push project to GitHub
- Create a Vercel project and connect to repo
- Set environment variables in Vercel dashboard (DB_HOST, DB_USER, DB_PASS, DB_NAME, ADMIN_PASSWORD)
- Deploy

Notes:
- Admin auth is password-only and stateless. Keep ADMIN_PASSWORD secret.
- The frontend expects the backend API under /api/admin when hosted together.